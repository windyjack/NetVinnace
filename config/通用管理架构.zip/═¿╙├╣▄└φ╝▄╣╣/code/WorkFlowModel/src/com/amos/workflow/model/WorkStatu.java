package com.amos.workflow.model;

public class WorkStatu {

	public static  final String WORK_PASS="WORK_SUCCESS";//�ɹ�
	public static  final String WORK_FAIL="WORK_FAIL";  //ʧ��
	public static  final String WORK_WAIT="WORK_HOLD_ON";  //�ȴ�
}
