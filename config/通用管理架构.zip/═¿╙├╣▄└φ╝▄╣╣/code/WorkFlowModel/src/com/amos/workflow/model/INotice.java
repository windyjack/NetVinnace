package com.amos.workflow.model;

public interface INotice {

}
