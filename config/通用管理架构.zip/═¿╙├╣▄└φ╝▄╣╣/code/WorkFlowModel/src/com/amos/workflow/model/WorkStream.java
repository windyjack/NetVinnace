package com.amos.workflow.model;

import java.io.File;
import java.util.Date;

import com.amos.workflow.service.WorkFlowService;

public class WorkStream implements IWorktream {

	private Notice notice;

	public Notice getNotice() {
		return notice;
	}

	
	public boolean pass(Notice notice){
		
		return false;
		
	}

	public Notice writeNotice(String work, String note, Sender sender,
			Recvtor recvtor,File file) {
		notice=new Notice();
		notice.setText(work);
		
		return notice;
	}


	public Notice readNotice(INotice notice) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
