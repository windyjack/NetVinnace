  select
        sysusers0_.UID as UID1_,
        sysusers0_.UROLE as UROLE1_,
        sysusers0_.dept as dept1_,
        sysusers0_.UNAME as UNAME1_,
        sysusers0_.USEX as USEX1_,
        sysusers0_.FPHONE as FPHONE1_,
        sysusers0_.SPHONE as SPHONE1_,
        sysusers0_.FMOBILE as FMOBILE1_,
        sysusers0_.SMOBILE as SMOBILE1_,
        sysusers0_.FADDRESS as FADDRESS1_,
        sysusers0_.SADDRESS as SADDRESS1_,
        sysusers0_.QQ as QQ1_,
        sysusers0_.MSN as MSN1_,
        sysusers0_.EMAIL as EMAIL1_,
        sysusers0_.STATU as STATU1_,
        sysusers0_.NOTE as NOTE1_ 
    from
        sys_users sysusers0_ limit 10