package com.amos.test;

import com.amos.utils.PageUtil;

public class CompTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PageUtil currentPage=new PageUtil();
		System.out.println(currentPage.getPageIndex());
		System.out.println(currentPage.getPageSize());

	}

}
