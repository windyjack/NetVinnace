package com.amos.web;

import java.util.Iterator;
import java.util.Set;
import com.amos.dao.CommonDao;
import com.amos.entry.Departments;
import com.amos.entry.Function;
import com.amos.entry.SysRole;
import com.amos.entry.SysUsers;
import com.amos.utils.IEntry;
import com.opensymphony.xwork2.ActionSupport;

public class TestAction extends ActionSupport {

	private CommonDao dao;
	

	@Override
	public String execute() throws Exception {

	//	IEntry role=dao.querySingleData(SysRole.class, "50001");
	//	SysRole roleTMP=(SysRole)role;
//		Set<Function> accList=(Set<Function>) roleTMP.getFunctionList();
//		Iterator<Function>itFun=accList.iterator();
//		while(itFun.hasNext()){
//			System.out.println(itFun.next().getFname());
//		}
		return SUCCESS;
	}
	
	
	public CommonDao getDao() {
		return dao;
	}
	public void setDao(CommonDao dao) {
		this.dao = dao;
	}

}
